from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
import jwt
from datetime import datetime, timedelta
from starlette.middleware.cors import CORSMiddleware  # Import CORSMiddleware

from sqlalchemy.orm import Session

# import bcrypt  # Import bcrypt for password hashing
from db import User, SessionLocal  # Import database setup and User model

app = FastAPI()

# Add CORS middleware to allow requests from the frontend (Next.js on port 3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Allow only the Next.js frontend
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"


# Pydantic model for login request
class LoginRequest(BaseModel):
    email: str
    password: str


# Pydantic model for user registration request
class RegisterRequest(BaseModel):
    email: str
    password: str
    full_name: str


# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Hash password using bcrypt
def hash_password(password: str):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode("utf-8"), salt)


# Verify the plain password against the hashed password
def verify_password(plain_password: str, hashed_password: bytes):
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password)


# Create JWT token
def create_access_token(data: dict, expires_delta: timedelta = timedelta(hours=1)):
    to_encode = data.copy()
    expiration = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expiration})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


# Login endpoint to authenticate users
@app.post("/login")
def login(request: LoginRequest, db: Session = Depends(get_db)):
    # Query the database for the user by email
    user = db.query(User).filter(User.email == request.email).first()

    if user is None or not verify_password(request.password, user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Create JWT token on successful login
    token = create_access_token({"sub": user.email})
    return {"success": True, "token": token}


# Register new user endpoint
@app.post("/register")
def register(request: RegisterRequest, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(User.email == request.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Hash the password and create the new user
    hashed_password = hash_password(request.password)
    new_user = User(
        email=request.email, password=hashed_password, full_name=request.full_name
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Generate JWT token for the new user
    token = create_access_token({"sub": new_user.email})

    return {"success": True, "token": token}
